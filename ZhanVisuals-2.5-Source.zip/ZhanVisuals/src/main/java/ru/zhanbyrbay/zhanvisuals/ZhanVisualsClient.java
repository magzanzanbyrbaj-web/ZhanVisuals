package ru.zhanbyrbay.zhanvisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;
import ru.zhanbyrbay.zhanvisuals.config.VisualConfig;
import ru.zhanbyrbay.zhanvisuals.gui.ZhanClickScreen;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * ZhanVisuals — client-side PvP visual helper for 1.21.11.
 */
public class ZhanVisualsClient implements ClientModInitializer {
    private static KeyMapping openMenuKey;
    private static final Deque<Long> leftClicks = new ArrayDeque<>();
    private static final Deque<Long> rightClicks = new ArrayDeque<>();

    @Override
    public void onInitializeClient() {
        VisualConfig.load();

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.zhanvisuals.open_menu",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new ZhanClickScreen());
                } else if (client.screen instanceof ZhanClickScreen) {
                    client.setScreen(null);
                }
            }
            long now = System.currentTimeMillis();
            while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000) leftClicks.pollFirst();
            while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000) rightClicks.pollFirst();
        });

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("zhanvisuals", "main_hud"),
                (graphics, deltaTracker) -> renderHud(graphics)
        );

        System.out.println("[ZhanVisuals] 2.5 ready — Right Shift = menu");
    }

    public static void onLeftClick() {
        leftClicks.addLast(System.currentTimeMillis());
    }

    public static void onRightClick() {
        rightClicks.addLast(System.currentTimeMillis());
    }

    private static void renderHud(GuiGraphicsExtractor graphics) {
        Minecraft mc = Minecraft.getInstance();
        if (!VisualConfig.hud || mc.player == null || mc.options.hideGui) return;
        if (mc.screen instanceof ZhanClickScreen) return;

        int color = VisualConfig.hudColor;
        int accent = VisualConfig.accentColor;
        int y = 8;
        int x = 8;

        if (VisualConfig.fps) {
            graphics.drawString(mc.font, Component.literal("FPS " + mc.getFps()), x, y, accent, true);
            y += 11;
        }

        if (VisualConfig.cps) {
            graphics.drawString(mc.font, Component.literal("CPS " + leftClicks.size() + " | " + rightClicks.size()), x, y, color, true);
            y += 11;
        }

        if (VisualConfig.coords) {
            var p = mc.player;
            String c = String.format("%.0f %.0f %.0f", p.getX(), p.getY(), p.getZ());
            graphics.drawString(mc.font, Component.literal(c), x, y, color, true);
            y += 11;
        }

        if (VisualConfig.ping) {
            int pingMs = 0;
            if (mc.getConnection() != null) {
                var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (info != null) pingMs = info.getLatency();
            }
            graphics.drawString(mc.font, Component.literal("Ping " + pingMs + "ms"), x, y, color, true);
            y += 11;
        }

        if (VisualConfig.totemCounter) {
            graphics.drawString(mc.font, Component.literal("Totems " + countTotems()), x, y, 0xFFFFD36A, true);
            y += 11;
        }

        if (VisualConfig.armorHud) {
            int ax = VisualConfig.armorHudX >= 0 ? VisualConfig.armorHudX : x;
            int ay = VisualConfig.armorHudY >= 0 ? VisualConfig.armorHudY : y;
            String[] labels = {"Boots", "Legs", "Chest", "Helm"};
            for (int i = 0; i < 4; i++) {
                ItemStack stack = mc.player.getInventory().getArmor(i);
                String line = labels[i] + ": " + (stack.isEmpty() ? "-" : (stack.getMaxDamage() - stack.getDamageValue()));
                graphics.drawString(mc.font, Component.literal(line), ax, ay + i * 11, color, true);
            }
        }

        if (VisualConfig.potionHud && !mc.player.getActiveEffects().isEmpty()) {
            int px = VisualConfig.potionHudX >= 0 ? VisualConfig.potionHudX : (mc.getWindow().getGuiScaledWidth() - 140);
            int py = VisualConfig.potionHudY >= 0 ? VisualConfig.potionHudY : 28;
            int row = 0;
            for (MobEffectInstance effect : mc.player.getActiveEffects()) {
                String name = effect.getEffect().value().getDisplayName().getString();
                int secs = effect.getDuration() / 20;
                String line = name + " " + (secs / 60) + ":" + String.format("%02d", secs % 60);
                graphics.drawString(mc.font, Component.literal(line), px, py + row * 11, color, true);
                row++;
                if (row > 8) break;
            }
        }

        if (VisualConfig.keystrokes) {
            int kx = mc.getWindow().getGuiScaledWidth() / 2 - 40;
            int ky = mc.getWindow().getGuiScaledHeight() - 80;
            drawKey(graphics, mc, "W", kx + 22, ky, mc.options.keyUp.isDown());
            drawKey(graphics, mc, "A", kx, ky + 22, mc.options.keyLeft.isDown());
            drawKey(graphics, mc, "S", kx + 22, ky + 22, mc.options.keyDown.isDown());
            drawKey(graphics, mc, "D", kx + 44, ky + 22, mc.options.keyRight.isDown());
            drawKey(graphics, mc, "LMB", kx, ky + 44, mc.options.keyAttack.isDown());
            drawKey(graphics, mc, "RMB", kx + 36, ky + 44, mc.options.keyUse.isDown());
        }
    }

    private static void drawKey(GuiGraphicsExtractor g, Minecraft mc, String label, int x, int y, boolean down) {
        int bg = down ? 0xAAFF3B4E : 0xAA1A1B25;
        g.fill(x, y, x + 20, y + 18, bg);
        g.drawCenteredString(mc.font, label, x + 10, y + 5, 0xFFFFFFFF);
    }

    public static int countTotems() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return 0;
        int total = mc.player.getInventory().countItem(Items.TOTEM_OF_UNDYING);
        if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) total++;
        return total;
    }
}
