package ru.zhanbyrbay.zhanvisuals.gui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ru.zhanbyrbay.zhanvisuals.config.VisualConfig;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Modern dark ClickGUI with red accents.
 * Categories: HUD, Combat Visuals, Animations, Performance, Settings
 */
public class ZhanClickScreen extends Screen {
    private static final String[] CATEGORIES = {
            "HUD", "Combat Visuals", "Animations", "Performance", "Settings"
    };

    private String selected = "HUD";
    private final List<Button> moduleButtons = new ArrayList<>();

    public ZhanClickScreen() {
        super(Component.literal("ZhanVisuals"));
    }

    @Override
    protected void init() {
        rebuildButtons();
    }

    private void rebuildButtons() {
        clearWidgets();
        moduleButtons.clear();

        int panelW = Math.min(520, this.width - 40);
        int panelH = Math.min(340, this.height - 40);
        int panelX = (this.width - panelW) / 2;
        int panelY = (this.height - panelH) / 2;

        // Category buttons (sidebar)
        int catY = panelY + 48;
        for (int i = 0; i < CATEGORIES.length; i++) {
            String cat = CATEGORIES[i];
            boolean active = cat.equals(selected);
            int by = catY + i * 28;
            Button catBtn = Button.builder(Component.literal(cat), b -> {
                selected = cat;
                rebuildButtons();
            }).bounds(panelX + 10, by, 110, 24).build();
            addRenderableWidget(catBtn);
        }

        // Module toggles
        if ("Settings".equals(selected)) {
            int mx = panelX + 140;
            int my = panelY + 50;
            addRenderableWidget(Button.builder(
                    Component.literal("Profile: " + VisualConfig.profileName()),
                    b -> {
                        VisualConfig.cycleProfile();
                        b.setMessage(Component.literal("Profile: " + VisualConfig.profileName()));
                    }
            ).bounds(mx, my, 200, 22).build());

            addRenderableWidget(Button.builder(Component.literal("Save & Close"), b -> onClose())
                    .bounds(mx, my + 40, 200, 22).build());
            return;
        }

        Map<String, Boolean> modules = VisualConfig.snapshotForCategory(selected);
        int row = 0;
        int mx = panelX + 140;
        int my = panelY + 50;
        for (Map.Entry<String, Boolean> e : modules.entrySet()) {
            String name = e.getKey();
            int by = my + row * 26;
            if (by + 24 > panelY + panelH - 20) break;
            Button btn = Button.builder(toggleLabel(name), b -> {
                VisualConfig.toggle(name);
                b.setMessage(toggleLabel(name));
            }).bounds(mx, by, 250, 22).build();
            moduleButtons.add(btn);
            addRenderableWidget(btn);
            row++;
        }
    }

    private Component toggleLabel(String name) {
        boolean on = VisualConfig.enabled(name);
        return Component.literal(name + "  " + (on ? "[ON]" : "[OFF]"));
    }

    @Override
    public void render(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        // Dim background
        graphics.fill(0, 0, this.width, this.height, 0xC00A0A10);

        int panelW = Math.min(520, this.width - 40);
        int panelH = Math.min(340, this.height - 40);
        int panelX = (this.width - panelW) / 2;
        int panelY = (this.height - panelH) / 2;

        // Main panel
        graphics.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF012121A);
        // Top accent
        graphics.fill(panelX, panelY, panelX + panelW, panelY + 2, VisualConfig.accentColor);
        // Header
        graphics.fill(panelX, panelY, panelX + panelW, panelY + 40, 0xE51A1B25);
        graphics.drawCenteredString(this.font, "ZHANVISUALS", this.width / 2, panelY + 14, VisualConfig.accentColor);

        // Sidebar background
        graphics.fill(panelX, panelY + 40, panelX + 130, panelY + panelH, 0xF00E0E16);

        // Hint
        graphics.drawString(this.font, Component.literal("Right Shift to close"), panelX + 12, panelY + panelH - 16, 0xFF6A6A78, false);

        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        VisualConfig.save();
        super.onClose();
    }
}
