package ru.zhanbyrbay.zhanvisuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Persistent client config for ZhanVisuals.
 * Saved as JSON in the config folder.
 */
public final class VisualConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("zhanvisuals.json");

    // --- HUD ---
    public static boolean hud = true;
    public static boolean fps = true;
    public static boolean cps = true;
    public static boolean coords = true;
    public static boolean ping = true;
    public static boolean armorHud = true;
    public static boolean totemCounter = true;
    public static boolean potionHud = true;
    public static boolean keystrokes = false;
    public static boolean targetHud = false;

    // --- Combat / Visual ---
    public static boolean customCrosshair = false;
    public static boolean lowFire = true;
    public static boolean hitParticles = true;
    public static boolean damageIndicators = false;

    // --- Animations ---
    public static boolean itemAnimations = true;
    public static boolean swordAnimations = true;

    // --- Performance ---
    public static boolean reduceParticles = false;
    public static boolean hideScoreboard = false;
    public static boolean optimizeHud = true;
    public static int performanceProfile = 1; // 0=Low 1=Medium 2=High

    // --- Appearance ---
    public static int accentColor = 0xFFFF3B4E; // red accent
    public static int hudColor = 0xFFE7E7EF;

    // --- HUD positions (draggable) ---
    public static int armorHudX = -1;
    public static int armorHudY = -1;
    public static int potionHudX = -1;
    public static int potionHudY = -1;

    private VisualConfig() {}

    public static void load() {
        if (!Files.exists(PATH)) {
            save();
            return;
        }
        try {
            String json = Files.readString(PATH);
            Data data = GSON.fromJson(json, Data.class);
            if (data == null) return;
            hud = data.hud;
            fps = data.fps;
            cps = data.cps;
            coords = data.coords;
            ping = data.ping;
            armorHud = data.armorHud;
            totemCounter = data.totemCounter;
            potionHud = data.potionHud;
            keystrokes = data.keystrokes;
            targetHud = data.targetHud;
            customCrosshair = data.customCrosshair;
            lowFire = data.lowFire;
            hitParticles = data.hitParticles;
            damageIndicators = data.damageIndicators;
            itemAnimations = data.itemAnimations;
            swordAnimations = data.swordAnimations;
            reduceParticles = data.reduceParticles;
            hideScoreboard = data.hideScoreboard;
            optimizeHud = data.optimizeHud;
            performanceProfile = data.performanceProfile;
            accentColor = data.accentColor;
            hudColor = data.hudColor;
            armorHudX = data.armorHudX;
            armorHudY = data.armorHudY;
            potionHudX = data.potionHudX;
            potionHudY = data.potionHudY;
        } catch (Exception e) {
            System.err.println("[ZhanVisuals] Failed to load config: " + e.getMessage());
        }
    }

    public static void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Data data = new Data();
            data.hud = hud;
            data.fps = fps;
            data.cps = cps;
            data.coords = coords;
            data.ping = ping;
            data.armorHud = armorHud;
            data.totemCounter = totemCounter;
            data.potionHud = potionHud;
            data.keystrokes = keystrokes;
            data.targetHud = targetHud;
            data.customCrosshair = customCrosshair;
            data.lowFire = lowFire;
            data.hitParticles = hitParticles;
            data.damageIndicators = damageIndicators;
            data.itemAnimations = itemAnimations;
            data.swordAnimations = swordAnimations;
            data.reduceParticles = reduceParticles;
            data.hideScoreboard = hideScoreboard;
            data.optimizeHud = optimizeHud;
            data.performanceProfile = performanceProfile;
            data.accentColor = accentColor;
            data.hudColor = hudColor;
            data.armorHudX = armorHudX;
            data.armorHudY = armorHudY;
            data.potionHudX = potionHudX;
            data.potionHudY = potionHudY;
            Files.writeString(PATH, GSON.toJson(data));
        } catch (IOException e) {
            System.err.println("[ZhanVisuals] Failed to save config: " + e.getMessage());
        }
    }

    public static Map<String, Boolean> snapshotForCategory(String category) {
        Map<String, Boolean> map = new LinkedHashMap<>();
        switch (category) {
            case "HUD" -> {
                map.put("Master HUD", hud);
                map.put("FPS Counter", fps);
                map.put("CPS Counter", cps);
                map.put("Coordinates", coords);
                map.put("Ping", ping);
                map.put("Armor HUD", armorHud);
                map.put("Totem Counter", totemCounter);
                map.put("Potion HUD", potionHud);
                map.put("Keystrokes", keystrokes);
                map.put("Target HUD", targetHud);
            }
            case "Combat Visuals" -> {
                map.put("Custom Crosshair", customCrosshair);
                map.put("Low Fire", lowFire);
                map.put("Hit Particles", hitParticles);
                map.put("Damage Indicators", damageIndicators);
            }
            case "Animations" -> {
                map.put("Item Animations", itemAnimations);
                map.put("Sword Animations", swordAnimations);
            }
            case "Performance" -> {
                map.put("Reduce Particles", reduceParticles);
                map.put("Hide Scoreboard", hideScoreboard);
                map.put("Optimize HUD", optimizeHud);
            }
            default -> {}
        }
        return map;
    }

    public static void toggle(String name) {
        switch (name) {
            case "Master HUD" -> hud = !hud;
            case "FPS Counter" -> fps = !fps;
            case "CPS Counter" -> cps = !cps;
            case "Coordinates" -> coords = !coords;
            case "Ping" -> ping = !ping;
            case "Armor HUD" -> armorHud = !armorHud;
            case "Totem Counter" -> totemCounter = !totemCounter;
            case "Potion HUD" -> potionHud = !potionHud;
            case "Keystrokes" -> keystrokes = !keystrokes;
            case "Target HUD" -> targetHud = !targetHud;
            case "Custom Crosshair" -> customCrosshair = !customCrosshair;
            case "Low Fire" -> lowFire = !lowFire;
            case "Hit Particles" -> hitParticles = !hitParticles;
            case "Damage Indicators" -> damageIndicators = !damageIndicators;
            case "Item Animations" -> itemAnimations = !itemAnimations;
            case "Sword Animations" -> swordAnimations = !swordAnimations;
            case "Reduce Particles" -> reduceParticles = !reduceParticles;
            case "Hide Scoreboard" -> hideScoreboard = !hideScoreboard;
            case "Optimize HUD" -> optimizeHud = !optimizeHud;
        }
        save();
    }

    public static boolean enabled(String name) {
        return switch (name) {
            case "Master HUD" -> hud;
            case "FPS Counter" -> fps;
            case "CPS Counter" -> cps;
            case "Coordinates" -> coords;
            case "Ping" -> ping;
            case "Armor HUD" -> armorHud;
            case "Totem Counter" -> totemCounter;
            case "Potion HUD" -> potionHud;
            case "Keystrokes" -> keystrokes;
            case "Target HUD" -> targetHud;
            case "Custom Crosshair" -> customCrosshair;
            case "Low Fire" -> lowFire;
            case "Hit Particles" -> hitParticles;
            case "Damage Indicators" -> damageIndicators;
            case "Item Animations" -> itemAnimations;
            case "Sword Animations" -> swordAnimations;
            case "Reduce Particles" -> reduceParticles;
            case "Hide Scoreboard" -> hideScoreboard;
            case "Optimize HUD" -> optimizeHud;
            default -> false;
        };
    }

    public static void cycleProfile() {
        performanceProfile = (performanceProfile + 1) % 3;
        switch (performanceProfile) {
            case 0 -> { // Low
                reduceParticles = true;
                hideScoreboard = true;
                optimizeHud = true;
                hitParticles = false;
            }
            case 1 -> { // Medium
                reduceParticles = false;
                hideScoreboard = false;
                optimizeHud = true;
                hitParticles = true;
            }
            case 2 -> { // High
                reduceParticles = false;
                hideScoreboard = false;
                optimizeHud = false;
                hitParticles = true;
            }
        }
        save();
    }

    public static String profileName() {
        return switch (performanceProfile) {
            case 0 -> "Low";
            case 1 -> "Medium";
            default -> "High";
        };
    }

    /** Gson data holder */
    public static class Data {
        public boolean hud = true, fps = true, cps = true, coords = true, ping = true;
        public boolean armorHud = true, totemCounter = true, potionHud = true;
        public boolean keystrokes = false, targetHud = false;
        public boolean customCrosshair = false, lowFire = true, hitParticles = true, damageIndicators = false;
        public boolean itemAnimations = true, swordAnimations = true;
        public boolean reduceParticles = false, hideScoreboard = false, optimizeHud = true;
        public int performanceProfile = 1;
        public int accentColor = 0xFFFF3B4E;
        public int hudColor = 0xFFE7E7EF;
        public int armorHudX = -1, armorHudY = -1, potionHudX = -1, potionHudY = -1;
    }
}
