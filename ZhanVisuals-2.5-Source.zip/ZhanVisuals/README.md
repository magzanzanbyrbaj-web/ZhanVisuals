# ZhanVisuals 2.5

Client-side Fabric PvP visual mod for Minecraft Java **1.21.11**.

## Features
- **ClickGUI** (Right Shift) — dark theme, red accents, categories
- **HUD**: FPS, CPS, Coordinates, Ping, Armor durability, Totems, Potions, Keystrokes
- **Combat Visuals**: Low Fire, Hit Particles, Crosshair, Damage Indicators (toggles)
- **Performance**: profiles Low / Medium / High, reduce particles, hide scoreboard
- **Config** saved to `config/zhanvisuals.json`

## Requirements
- Minecraft 1.21.11
- Fabric Loader ≥ 0.19.5
- Fabric API for 1.21.11
- Java 21

## Build
```bash
./gradlew build
```
JAR: `build/libs/zhanvisuals-2.5.0.jar`

## Controls
- **Right Shift** — open / close menu

## Notes
- Client-only, no server install needed.
- Compatible with Sodium / Iris / ImmediatelyFast.
- Some combat visuals are toggles stored in config; full rendering hooks may need extra mixins depending on renderer.
